# FleetPilot V15.6 — Modular Codebase

This release reorganizes the working V15.5 code without intentionally changing business logic.
The goal is simple: each future fix can replace only the file responsible for that area.

## JavaScript map

| File | Responsibility |
|---|---|
| `js/00-core-data.js` | Models, demo seed, local database, save/load, helpers, UX mode, theme |
| `js/01-roles-company.js` | Existing roles, permissions, Company page, workspace access |
| `js/02-driver-portal.js` | Driver mobile portal, driver requests, assignments, notifications |
| `js/03-router-navigation.js` | Routes, page switching, deep links, mobile/desktop navigation |
| `js/04-files-backups.js` | Attachments, IndexedDB files, backups, damages/history helpers |
| `js/05-analytics-dashboard.js` | Dashboard, search, attention center, analytics, owner KPIs |
| `js/06-gps-map.js` | GPS configuration and all Leaflet map logic |
| `js/07-fleet.js` | Fleet / vehicle list, cards, filters and rendering |
| `js/08-service-finance.js` | Service queue, repairs, payments, expenses, profitability |
| `js/09-calendar-vehicle.js` | Calendar, Vehicle Core/profile, car finance drilldown |
| `js/10-actions-documents.js` | CRUD actions, document dialog/files, deposits and form handlers |
| `js/11-boot-hotfixes.js` | Startup plus compatibility overrides/hotfixes from later versions |

## CSS map

| File | Responsibility |
|---|---|
| `css/00-base-legacy.css` | Base UI, controls and early shared styling |
| `css/01-service-layout.css` | Service styling and desktop layout foundations |
| `css/02-desktop-gps.css` | Desktop workspace, maps and GPS |
| `css/03-cloud-roles.css` | Auth, cloud workspace, company and roles |
| `css/04-driver.css` | Driver/mobile-specific screens |
| `css/05-crm-service.css` | Modern CRM/service system and shared professional typography |
| `css/06-current-ui.css` | Current V14–V15 UI: Vehicle Core, finance, documents, responsive/mobile fixes |

## Important rule

The files are loaded in numeric order. Do not change that order unless the dependencies are deliberately refactored.

## Future update examples

Mobile menu fix:
- replace `js/03-router-navigation.js`
- replace `css/06-current-ui.css` only if visual CSS also changed

Documents fix:
- replace `js/10-actions-documents.js`
- replace `css/06-current-ui.css`

Service fix:
- replace `js/08-service-finance.js`
- replace `css/05-crm-service.css` only when styling changes

Vehicle profile fix:
- replace `js/09-calendar-vehicle.js`
- replace `css/06-current-ui.css`

Roles/permissions fix:
- replace `js/01-roles-company.js`

GPS fix:
- replace `js/06-gps-map.js`
- replace `css/02-desktop-gps.css` only when styling changes

## Deployment

Upload the contents of this folder. Old ZIP archives, `menu_debug`, `work`, README backups and restore JSON files are intentionally not included.
