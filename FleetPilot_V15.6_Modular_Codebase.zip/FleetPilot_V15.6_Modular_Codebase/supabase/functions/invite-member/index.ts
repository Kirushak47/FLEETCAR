import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const allowedRoles = new Set([
  "owner",
  "coordinator",
  "accountant",
  "mechanic",
  "driver",
]);

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (request.method !== "POST") {
    return json({ ok: false, error: "Method not allowed" }, 405);
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !anonKey || !serviceRoleKey) {
      return json({ ok: false, error: "Server configuration is incomplete" }, 500);
    }

    const authorization = request.headers.get("Authorization");
    if (!authorization) {
      return json({ ok: false, error: "Authentication required" }, 401);
    }

    // Authenticate the caller with their JWT.
    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authorization } },
      auth: { persistSession: false },
    });

    const {
      data: { user },
      error: userError,
    } = await userClient.auth.getUser();

    if (userError || !user) {
      return json({ ok: false, error: "Invalid session" }, 401);
    }

    // service_role stays only inside the Edge Function.
    const admin = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: membership, error: membershipError } = await admin
      .from("workspace_members")
      .select("workspace_id, role, status")
      .eq("user_id", user.id)
      .eq("status", "active")
      .limit(1)
      .maybeSingle();

    if (membershipError) throw membershipError;

    if (!membership || membership.role !== "owner") {
      return json(
        { ok: false, error: "Only the fleet owner can invite users" },
        403,
      );
    }

    const payload = await request.json();
    const email = String(payload?.email ?? "").trim().toLowerCase();
    const role = String(payload?.role ?? "").trim();
    const city = String(payload?.city ?? "").trim() || null;

    if (!email || !email.includes("@")) {
      return json({ ok: false, error: "Invalid email address" }, 400);
    }

    if (!allowedRoles.has(role)) {
      return json({ ok: false, error: "Invalid role" }, 400);
    }

    if (email === String(user.email ?? "").toLowerCase()) {
      return json(
        { ok: false, error: "You cannot invite your own email" },
        400,
      );
    }

    const expiresAt = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000)
      .toISOString();

    // Reuse an existing pending invite or create a new one.
    const { data: currentInvite, error: currentInviteError } = await admin
      .from("workspace_invites")
      .select("id")
      .eq("workspace_id", membership.workspace_id)
      .ilike("email", email)
      .eq("status", "pending")
      .maybeSingle();

    if (currentInviteError) throw currentInviteError;

    let inviteId: string;

    if (currentInvite?.id) {
      const { error: updateError } = await admin
        .from("workspace_invites")
        .update({
          role,
          city,
          invited_by: user.id,
          expires_at: expiresAt,
        })
        .eq("id", currentInvite.id);

      if (updateError) throw updateError;
      inviteId = currentInvite.id;
    } else {
      const { data: inserted, error: insertError } = await admin
        .from("workspace_invites")
        .insert({
          workspace_id: membership.workspace_id,
          email,
          role,
          city,
          status: "pending",
          invited_by: user.id,
          expires_at: expiresAt,
        })
        .select("id")
        .single();

      if (insertError) throw insertError;
      inviteId = inserted.id;
    }

    const redirectTo = Deno.env.get("APP_REDIRECT_URL") ||
      "https://kirushak47.github.io/FLEETCAR/?invited=1";

    const { error: inviteError } = await admin.auth.admin.inviteUserByEmail(
      email,
      {
        redirectTo,
        data: {
          workspace_id: membership.workspace_id,
          workspace_invite_id: inviteId,
          workspace_role: role,
          workspace_city: city,
        },
      },
    );

    if (inviteError) {
      const message = inviteError.message.toLowerCase();

      // Existing accounts cannot receive an Auth "invite" email. Their
      // workspace invitation remains pending and is accepted after login.
      if (
        message.includes("already") ||
        message.includes("registered") ||
        message.includes("exists")
      ) {
        return json({
          ok: true,
          emailSent: false,
          existingUser: true,
          inviteId,
          message:
            "Invitation saved. The user already has an account and should sign in.",
        });
      }

      // Roll back the pending invite if email delivery itself failed.
      await admin
        .from("workspace_invites")
        .update({ status: "cancelled" })
        .eq("id", inviteId);

      throw inviteError;
    }

    return json({
      ok: true,
      emailSent: true,
      existingUser: false,
      inviteId,
    });
  } catch (error) {
    console.error("invite-member", error);
    return json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unexpected error",
      },
      500,
    );
  }
});
